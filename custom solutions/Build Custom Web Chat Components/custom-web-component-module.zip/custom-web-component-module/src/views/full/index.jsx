/**
 * This file is the full view of your module. It automatically includes heavy dependencies, like react-bootstrap
 * If you want to display an interface for your module, export your principal view as "default"
 */
export default class MyMainView extends React.Component {
  render() {
    return <div>Some interface</div>
  }
}
